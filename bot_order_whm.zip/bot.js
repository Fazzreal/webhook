const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const axios = require('axios');
const express = require('express');
const bodyParser = require('body-parser');
const config = require('./config');

const app = express();
app.use(bodyParser.json());

let sock;

// Fungsi untuk memulai koneksi WhatsApp
async function startWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('session');
    sock = makeWASocket({ auth: state });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', ({ connection }) => {
        if (connection === 'open') {
            console.log('Bot WhatsApp terhubung!');
        } else if (connection === 'close') {
            console.log('Koneksi terputus, mencoba menghubungkan ulang...');
            startWhatsApp();
        }
    });

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || !msg.key.remoteJid) return;

        const sender = msg.key.remoteJid;
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

        if (text.startsWith('/buywhm')) {
            const buyMsg = `📌 Cara Pembelian WHM

1️⃣ Kunjungi Trakteer: ${config.TRAKTEER_URL}
2️⃣ Pilih jumlah yang sesuai dengan paket
3️⃣ Isi pesan dengan format:
   🔹 [Paket] [Username] [Nomor WhatsApp]
   Contoh: Whm Medium user123 6281234567890
4️⃣ Lakukan pembayaran.

✅ Bot akan otomatis mengonfirmasi pembayaran dan mengaktifkan layanan.`;
            await sock.sendMessage(sender, { text: buyMsg });
        }
    });
}

// Webhook untuk menangani pembayaran sukses dari Trakteer
app.post('/webhook/trakteer', (req, res) => {
    const secret = req.headers['x-trakteer-secret'];
    if (secret !== config.TRAKTEER_WEBHOOK_SECRET) {
        return res.status(403).send("Invalid Webhook Secret");
    }

    const { status, price, message } = req.body;

    if (status === 'success') {
        const match = message.match(/(Whm Mini|Whm Medium|Whm Extra|Whm Super) (\w+) (\d+)/);
        if (!match) {
            console.log("Format pesan tidak valid:", message);
            return res.send("OK");
        }

        const [ , packageName, username, phoneNumber ] = match;
        const expectedPrice = config.PACKAGES[packageName];
        const userJid = phoneNumber + "@s.whatsapp.net";

        if (!expectedPrice) {
            const invalidMsg = `❌ Format data salah!

Harap isi pesan di Trakteer dengan format:
[Paket] [Username] [Nomor WhatsApp]

Contoh:
Whm Medium user123 6281234567890`;
            sock.sendMessage(userJid, { text: invalidMsg });
            return res.send("OK");
        }

        if (price < expectedPrice) {
            const shortMsg = `❌ Pembayaran kurang!

🔹 Paket: ${packageName}
💳 Harga: Rp ${expectedPrice}
📥 Diterima: Rp ${price}

Silakan transfer sisa kekurangan!`;
            sock.sendMessage(userJid, { text: shortMsg });
        } else if (price > expectedPrice) {
            const overMsg = `⚠️ Pembayaran kelebihan!

🔹 Paket: ${packageName}
💳 Harga: Rp ${expectedPrice}
📥 Diterima: Rp ${price}

Kelebihan saldo bisa digunakan untuk pembelian berikutnya.`;
            sock.sendMessage(userJid, { text: overMsg });
        } else {
            const successMsg = `✅ Pembayaran sukses!

🔹 Paket: ${packageName}
🔹 Username: ${username}
💳 Harga: Rp ${price}

Layanan WHM telah diaktifkan!`;
            sock.sendMessage(userJid, { text: successMsg });
        }
    }

    res.send("OK");
});

// Mulai server Express
app.listen(config.PORT, () => {
    console.log(`Webhook berjalan di port ${config.PORT}`);
});

// Mulai WhatsApp bot
startWhatsApp();
