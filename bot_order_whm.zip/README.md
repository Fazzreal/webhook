# Bot Order WHM Otomatis

Bot ini memungkinkan pembelian paket WHM melalui Trakteer dengan verifikasi otomatis.

## 🚀 Cara Menjalankan
1. **Install dependencies**:
   ```sh
   npm install
   ```
2. **Jalankan bot**:
   ```sh
   npm start
   ```

## 📌 Cara Order WHM
1. Kirim perintah `/buywhm` di WhatsApp untuk mendapatkan informasi pembelian.
2. Kunjungi **Trakteer** dan lakukan pembayaran dengan mengisi pesan sesuai format:
   ```
   [Paket] [Username] [Nomor WhatsApp]
   ```
   Contoh:
   ```
   Whm Medium user123 6281234567890
   ```

Bot akan otomatis memproses pembayaran dan mengirimkan detail akun WHM ke WhatsApp.

## 🔧 Konfigurasi
Edit file `config.js` untuk mengatur:
- **API Key Trakteer**
- **Webhook Secret**
- **Nomor WhatsApp Owner**
- **Daftar Paket & Harga**
