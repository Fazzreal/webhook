module.exports = {
    PORT: 3000,
    TRAKTEER_WEBHOOK_SECRET: "isi_webhook_secret_kamu",
    TRAKTEER_API_KEY: "isi_api_key_kamu",
    OWNER_NUMBER: "62XXXXXXXXXX",
    TRAKTEER_URL: "https://trakteer.id/namakamu", // Ganti dengan URL Trakteer kamu
    PACKAGES: {
        "Whm Mini": 10000,
        "Whm Medium": 25000,
        "Whm Extra": 50000,
        "Whm Super": 100000
    }
};
